for cycle = 1, 3 do
    nLog("===== START CYCLE: " .. cycle .. " =====")

    local ok, err = pcall(function()

         nLog("===== START NEW CYCLE =====")
    -- ================= CHECK & FORCE DELETE TIKTOK =================
nLog("🔍 Check TikTok trước khi chạy...")

local function ensureTikTokDeleted()
    local retry = 0
    local MAX_RETRY = 5

    while retry < MAX_RETRY do
        retry = retry + 1
        nLog("Check uninstall lần: " .. retry)

        local ok, msg = app.uninstall("com.ss.iphone.ugc.tiktok.lite")
        sys.sleep(5)
		app.quit("*")
        sys.sleep(2)
        if ok then
            nLog("✔ TikTok đã được xóa")
            return true
        else
            nLog("Uninstall trả về: " .. tostring(msg))

            -- 🔥 QUAN TRỌNG: app không tồn tại
            if string.find(tostring(msg), "111") then
                nLog("✔ TikTok không tồn tại → OK")
                return true
            end
        end

        sys.sleep(5)
    end

    nLog("❌ Không thể đảm bảo TikTok đã xóa")
    return false
end

-- chạy check
ensureTikTokDeleted()


    

nLog("Open appstore...")
sys.sleep(2)
app.run("com.apple.AppStore")
sys.sleep(8)



local x, y
while x == nil do
    nLog("Find “profile” button…")
    sys.sleep(8)
    -- Generated code
    x, y = screen.find_color({
	{1128,253,0x007aff},
	{1127,218,0x007aff},
	{1129,283,0x007aff},
	{1089,284,0x007aff},
	{1167,285,0x007aff},
},95,1060,190,1172,324)
end

nLog("Tap “profile”…")
sys.sleep(2)
touch.tap(x, y)
sys.sleep(5)


local function tapWord(word)
    local txts, details = screen.ocr_text {}
    
    for i, v in ipairs(txts) do
        -- so sánh mềm (an toàn hơn)
        if string.find(string.lower(v), string.lower(word), 1, true) then
            touch.tap(details[i].center[1], details[i].center[2])
            return true
        end
    end

    return false
end

nLog("Tap 'Purchased'...")

while not tapWord("Purchased") do
    sys.msleep(300)
end

-- bấm lite
local function tapWord(word)
    local txts, details = screen.ocr_text {}
    
    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            touch.tap(details[i].center[1], details[i].center[2])
            return true
        end
    end

    return false
end

nLog("Tap 'Lite'...")


local timeout = 300 -- số giây bạn muốn chờ
local start = os.time()

while (os.time() - start) < timeout do
    if tapWord("Lite") then
        nLog("Đã tìm thấy và tap Lite")
        break
    end

    sys.msleep(3000)
end

-- nếu hết thời gian mà chưa thấy
if (os.time() - start) >= timeout then
    nLog("Timeout: không tìm thấy Lite")
end

sys.sleep(5)


local x, y
while x == nil do
    nLog("Find “tải về” button…")
    sys.sleep(5)
    -- Generated code
    x, y = screen.find_color({
	{505,594,0x007aff},
	{504,627,0x007aff},
	{473,583,0x007aff},
	{528,580,0x007aff},
	{534,607,0x007aff},
	{477,608,0x007aff},
},95,0,0,0,0)
end

nLog("Tap “tải về”…")
sys.sleep(2)
touch.tap(x, y)
sys.sleep(300)
app.close("com.apple.AppStore")
sys.sleep(2)
-- bấm open
local function hasWord(word)
    local txts, details = screen.ocr_text {}

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return true
        end
    end

    return false
end

nLog("Đợi thấy 'Tiktok'...")

local timeout = 900
local start = os.time()

while (os.time() - start) < timeout do
    if hasWord("tiktoklite") then
        nLog("Đã thấy TiktokLite → mở app")
        sys.sleep(20)
        app.run("com.ss.iphone.ugc.tiktok.lite")
        break
    end

    sys.msleep(3000)
end

if (os.time() - start) >= timeout then
    nLog("Timeout: không thấy Tiktok")
end
sys.sleep(50)


-- bấm don't allow
local function tapDontAllow(timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        nLog("Đang tìm 'Don't Allow'...")

        local txts, details = screen.ocr_text {}

        for i, v in ipairs(txts) do
            local text = string.lower(v)

            if string.find(text, "don't allow") or string.find(text, "dont allow") then
                local x = details[i].center[1]
                local y = details[i].center[2]

                nLog("Thấy → tap")
                touch.tap(x, y)
                sys.sleep(1)

                -- 🔁 check lại 1 lần sau khi tap
                local txts2, details2 = screen.ocr_text {}
                for j, v2 in ipairs(txts2) do
                    local text2 = string.lower(v2)

                    if string.find(text2, "don't allow") or string.find(text2, "dont allow") then
                        local x2 = details2[j].center[1]
                        local y2 = details2[j].center[2]

                        nLog("Vẫn còn → tap lần 2")
                        touch.tap(x2, y2)
                        sys.sleep(1)
                        break
                    end
                end

                return true
            end
        end

        sys.msleep(1500) -- delay giữa mỗi lần check
    end

    nLog("Hết thời gian → không thấy")
    return false
end

-- ===== RUN =====
tapDontAllow(30) -- chờ tối đa 20s


sys.sleep(15)



-- tap nhiều ngẫu nhiên
math.randomseed(os.time())

local function tapMultiRandom(words, minTap, maxTap)
    local txts, details = screen.ocr_text {}
    local candidates = {}

    -- lấy danh sách match
    for i, v in ipairs(txts) do
        local text = string.lower(v)

        for _, w in ipairs(words) do
            if string.find(text, string.lower(w), 1, true) then
                table.insert(candidates, {
                    x = details[i].center[1],
                    y = details[i].center[2],
                    text = v
                })
                break
            end
        end
    end

    if #candidates == 0 then
        return false
    end

    -- shuffle danh sách
    for i = #candidates, 2, -1 do
        local j = math.random(i)
        candidates[i], candidates[j] = candidates[j], candidates[i]
    end

    -- random số lượng tap
    local count = math.random(minTap, maxTap)
    count = math.min(count, #candidates) -- tránh vượt quá

    nLog("Số lần tap: " .. count)

    -- tap
    for i = 1, count do
        local item = candidates[i]
        touch.tap(item.x, item.y)
        nLog("Tap: " .. item.text)
        sys.msleep(1000)
    end

    return true
end


local list = {"comedy", "daily", "dance"}

tapMultiRandom(list, 1, 3)

sys.sleep(5)


-- bấm next
local function tapWord(word)
    local txts, details = screen.ocr_text {}
    
    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            touch.tap(details[i].center[1], details[i].center[2])
            return true
        end
    end

    return false
end

nLog("Tap 'Next'...")

local timeout = 20 -- số giây bạn muốn chờ
local start = os.time()

while (os.time() - start) < timeout do
    if tapWord("Next") then
        nLog("Đã tìm thấy và tap Next")
        break
    end

    sys.msleep(3000)
end

-- nếu hết thời gian mà chưa thấy
if (os.time() - start) >= timeout then
    nLog("Timeout: không tìm thấy Next")
end

sys.sleep(10)

-- ================= SWIPE BLOCK =================

-- swipe chắc tay hơn
local function swipeUp()
    local w, h = screen.size()

    local x = w * (0.45 + math.random()*0.1)

    touch.on(x, h*0.85)          -- bắt đầu thấp hơn
        :move(x, h*0.65)
        :move(x, h*0.45)
        :move(x, h*0.20)         -- kết thúc cao hơn
        :step_delay(10 + math.random(5))
        :step_len(12 + math.random(4)) -- tăng lực
        :off()
end

-- OCR mềm hơn (tránh miss chữ Swipe)
local function hasWordSwipe()
    local txts, _ = screen.ocr_text {}

    for i, v in ipairs(txts) do
        local text = string.lower(v)

        if string.find(text, "swipe") 
        or string.find(text, "swlpe") 
        or string.find(text, "5wipe") then
            return true
        end
    end

    return false
end

nLog("Find Swipe...")

local timeout = 300
local start = os.time()
local found = false

-- tìm chữ Swipe
while (os.time() - start) < timeout do
    if hasWordSwipe() then
        found = true
        break
    end

    swipeUp()
    sys.msleep(5000)
end

-- ================= FLOW =================
if found then
    nLog("Đã thấy Swipe → vuốt")

    sys.msleep(1500)

    local count = math.random(1, 2)
    for i = 1, count do
        swipeUp()
        sys.msleep(2000)
    end

    nLog("Chờ 20s để Ask xuất hiện...")
    sys.msleep(15000)

else
    nLog("Không thấy Swipe → vuốt fallback")

    for i = 1, 2 do
        swipeUp()
        sys.msleep(2000)
    end
end
sys.sleep(10)

-- ================= END =================
    -- ================= TÌM & TAP ASK =================
local function tapAskNotTrack(timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        nLog("Đang tìm 'Ask App Not to Track'...")

        local txts, details = screen.ocr_text {}

        for i, v in ipairs(txts) do
            local text = string.lower(v)

            if string.find(text, "ask") 
            and string.find(text, "not") 
            and string.find(text, "track") then

                local x = details[i].center[1]
                local y = details[i].center[2]

                nLog("Thấy → tap lần 1")
                touch.tap(x, y)
                nLog("đã tap")
                sys.sleep(1.5)

                -- 🔁 CHECK LẠI 1 LẦN
                local txts2, details2 = screen.ocr_text {}

                for j, v2 in ipairs(txts2) do
                    local text2 = string.lower(v2)

                    if string.find(text2, "ask") 
                    and string.find(text2, "not") 
                    and string.find(text2, "track") then

                        local x2 = details2[j].center[1]
                        local y2 = details2[j].center[2]

                        nLog("Vẫn còn → tap lần 2")
                        touch.tap(x2, y2)
                        sys.sleep(1)
                        break
                    end
                end

                return true
            end
        end

        sys.msleep(1500)
    end

    nLog("Hết thời gian → không thấy")
    return false
end

-- ===== RUN =====
tapAskNotTrack(30)
            
sys.sleep(10)            
    local patterns = {
    {1022,376,0x696969},
	{1025,373,0x686868},
	{1036,366,0xb2b2b2},
	{1016,367,0xb2b2b2},
	{1036,388,0xb3b3b3},
	{1029,377,0x696969},
}

local function checkAndTap()
    local ok = true

    for i, p in ipairs(patterns) do
        local x, y, color = p[1], p[2], p[3]
        local c = screen.get_color(x, y)

        if c ~= color then
            ok = false
            break
        end
    end

    -- nếu tất cả màu đúng → tap vào 1 điểm cố định
    if ok then
        nLog("Match chuẩn → tap")
        touch.tap(patterns[1][1], patterns[1][2]) -- tap điểm đầu
        return true
    end

    return false
end

            local timeout = 20
local start = os.time()

while (os.time() - start) < timeout do
    nLog("Check X bằng pixel...")
    sys.msleep(1000)

    if checkAndTap() then
        sys.sleep(3)
        break
    end
end

if (os.time() - start) >= timeout then
    nLog("Không match → bỏ qua")
end
    -- ================= SWIPE RANDOM SAU ĐÓ =================
    local count = math.random(1, 2)
    nLog("Swipe tiếp: " .. count .. " lần")

    for i = 1, count do
        swipeUp()

        local delay = math.random(8000, 15000)
        nLog("Chờ: " .. delay .. " ms")
        sys.msleep(delay)
    end
sys.sleep(8)

local x, y
while x == nil do
    nLog("Find “P sự kiện” button…")
    sys.sleep(5)
    -- Generated code
    x, y = screen.find_color({
	{352,2092,0xffd31b},
	{350,2127,0xff9900},
	{395,2135,0xffd31b},
	{393,2108,0xff9900},
	{372,2112,0xff9900},
},95,0,0,0,0)
end

nLog("Tap “sự kiện”…")
sys.sleep(2)
touch.tap(x, y)
sys.sleep(10)
        
app.close("com.ss.iphone.ugc.tiktok.lite")

sys.sleep(5)

app.run("com.tigisoftware.ADManager")
            nLog("mở manager")
            
sys.sleep(5)

-- ================= CONFIG =================
-- chỉnh vùng scan cho phù hợp máy bạn
local SCAN_REGION = {
    x = 30,
    y = 488,      -- bỏ header phía trên
    width = 547,
    height = 1054
}

-- ================= FUNCTION =================
-- tìm text trong vùng
local function findTextInRegion(word)
    local txts, details = screen.ocr_text {
        region = SCAN_REGION
    }

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return details[i].center[1], details[i].center[2], v
        end
    end

    return nil, nil, nil
end

-- tap text trong vùng + timeout
local function tapTextInRegion(word, timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        local x, y, text = findTextInRegion(word)

        if x ~= nil then
            nLog("Tap: " .. text .. " tại (" .. x .. "," .. y .. ")")
            touch.tap(x, y)
            return true
        end

        sys.msleep(300)
    end

    nLog("Timeout: không tìm thấy " .. word)
    return false
end

-- ================= USE =================
nLog("Tap 'TikTok' trong manager...")

if tapTextInRegion("TikTok", 20) then
    sys.sleep(2) -- chờ chuyển màn
else
    nLog("Không tìm thấy TikTok")
end



-- chỉnh vùng scan cho phù hợp máy bạn
local SCAN_REGION = {
    x = 1,
    y = 1543,      -- bỏ header phía trên
    width = 381,
    height = 1681
}

-- ================= FUNCTION =================
-- tìm text trong vùng
local function findTextInRegion(word)
    local txts, details = screen.ocr_text {
        region = SCAN_REGION
    }

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return details[i].center[1], details[i].center[2], v
        end
    end

    return nil, nil, nil
end

-- tap text trong vùng + timeout
local function tapTextInRegion(word, timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        local x, y, text = findTextInRegion(word)

        if x ~= nil then
            nLog("Tap: " .. text .. " tại (" .. x .. "," .. y .. ")")
            touch.tap(x, y)
            return true
        end

        sys.msleep(300)
    end

    nLog("Timeout: không tìm thấy " .. word)
    return false
end

-- ================= USE =================
nLog("Tap 'Backup' trong vùng list...")

if tapTextInRegion("Backup", 20) then
    sys.sleep(2) -- chờ chuyển màn
else
    nLog("Không tìm thấy Backup")
end
sys.sleep(5)

local x, y
while x == nil do
    nLog("Find “Backup” button…")
    sys.sleep(5)
    -- Generated code
	x, y = screen.find_color({
	{325,1885,0x007aff},
	{547,1887,0x007aff},
	{571,1885,0x007aff},
	{600,1921,0x007aff},
	{691,1896,0x007aff},
	{737,1883,0x007aff},
},95,269,1826,976,1977)
end

nLog("Tap “Backup”…")
sys.sleep(2)
touch.tap(x, y)
sys.sleep(5)


local x, y
while x == nil do
    nLog("Find “Backing...” button…")
    sys.sleep(20)
    -- Generated code
	x, y = screen.find_color({
	{471,1008,0xffffff},
	{580,1008,0xffffff},
	{516,1059,0x007aff},
	{654,1057,0x007aff},
	{581,1089,0x007aff},
},95,0,0,0,0)
end
sys.sleep(5)
            
            
local SCAN_REGION = {
    x = 3,
    y = 1925,      -- bỏ header phía trên
    width = 348,
    height = 2055
}

-- ================= FUNCTION =================
-- tìm text trong vùng
local function findTextInRegion(word)
    local txts, details = screen.ocr_text {
        region = SCAN_REGION
    }

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return details[i].center[1], details[i].center[2], v
        end
    end

    return nil, nil, nil
end

-- tap text trong vùng + timeout
local function tapTextInRegion(word, timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        local x, y, text = findTextInRegion(word)

        if x ~= nil then
            nLog("Tap: " .. text .. " tại (" .. x .. "," .. y .. ")")
            touch.tap(x, y)
            return true
        end

        sys.msleep(1000)
    end

    nLog("Timeout: không tìm thấy " .. word)
    return false
end

-- ================= USE =================
nLog("Tap 'wipe' trong vùng list...")

if tapTextInRegion("Wipe", 20) then
    sys.sleep(2) -- chờ chuyển màn
else
    nLog("Không tìm thấy Wipe")
end
sys.sleep(5)
local x, y
while x == nil do
    nLog("Find “wipe” button…")
    sys.sleep(5)
    -- Generated code
	x, y = screen.find_color({
	{355,1890,0xff3b30},
	{411,1885,0xff3b30},
	{539,1885,0xff3b30},
	{707,1885,0xff3b30},
	{675,1922,0xff3b30},
},95,267,1826,1007,1987)
end

sys.sleep(2)
touch.tap(x, y)
sys.toast("đã bấm wipe", 0)
nLog("đã bấm wipe")
sys.sleep(10)

app.quit("*")

sys.sleep(5)

local function hasWord(word)
    local txts, details = screen.ocr_text {}

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return true
        end
    end

    return false
end

nLog("Đợi thấy 'Tiktok'...")

local timeout = 10
local start = os.time()

while (os.time() - start) < timeout do
    if hasWord("tiktok") then
        nLog("Đã thấy Tiktok → xóa app")
        app.uninstall("com.ss.iphone.ugc.tiktok.lite")
        break
    end

    sys.msleep(3000)
end

if (os.time() - start) >= timeout then
    nLog("Timeout: không thấy Tiktok")
end            
sys.sleep(5)

-- 🔥 QUIT ALL APP SAU KHI CLEAN
nLog("Quit all app...")
app.quit("*")

sys.sleep(5)

nLog("Kết thúc")


sys.sleep(5)
            -- ================= FINAL CLEAN UP (SAU KHI CHẠY XONG 1 VÒNG) =================
-- ================= FINAL CLEAN UP (SAU KHI CHẠY XONG 1 VÒNG) =================
nLog("===== FINAL CLEAN UP =====")

local bundle = "com.ss.iphone.ugc.tiktok.lite"

-- 🔥 CHECK TRỰC TIẾP BUNDLE (KHÔNG DÙNG OCR)
nLog("🔍 Check TikTokLite còn hay không...")

local maxTry = 3
local count = 0

while count < maxTry do
    if not app.installed(bundle) then
        nLog("✔ Không còn TikTokLite → thoát clean")
        break
    end

    nLog("⚠ TikTokLite vẫn còn → uninstall lần " .. (count + 1))

    local ok, msg = app.uninstall(bundle)

    if ok then
        nLog("✔ Đã gọi uninstall")
    else
        nLog("❌ Lỗi uninstall: " .. tostring(msg))
    end

    sys.sleep(3) -- đợi hệ thống xóa thật
    count = count + 1
end

if count == maxTry then
    nLog("❌ Vẫn còn TikTokLite sau " .. maxTry .. " lần thử")
end

sys.sleep(3)

-- 🔥 QUIT ALL APP SAU KHI CLEAN
nLog("🚀 Quit all app...")
app.quit("*")

sys.sleep(5)

nLog("===== END CLEAN CYCLE =====")


    end)

    if not ok then
        nLog("❌ Lỗi vòng " .. cycle .. ": " .. tostring(err))
    else
        nLog("✅ Hoàn thành vòng " .. cycle)
    end

    -- nghỉ giữa các vòng (rất quan trọng để tránh dính trạng thái hệ thống)
    if cycle < 3 then
        nLog("⏳ Nghỉ trước vòng tiếp...")
        sys.sleep(10) -- có thể tăng 20-30s nếu máy yếu
    end
end

nLog("🎉 DONE 3 CYCLES")