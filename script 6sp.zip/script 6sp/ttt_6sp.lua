sys.toast("BẮT ĐẦU CHẠY TOOL",0)
for cycle = 1, 3 do
    nLog("===== START CYCLE: " .. cycle .. " =====")

    local ok, err = pcall(function()

         nLog("===== START NEW CYCLE =====")
    -- ================= CHECK & FORCE DELETE TIKTOK =================
nLog("🔍 Check TikTok trước khi chạy...")

local function ensureTikTokDeleted()
    local retry = 0
    local MAX_RETRY = 5

    while retry < MAX_RETRY do
        retry = retry + 1
        nLog("Check uninstall lần: " .. retry)

        local ok, msg = app.uninstall("com.ss.iphone.ugc.Ame")
        sys.sleep(5)
		app.quit("*")
        sys.sleep(2)
        if ok then
            nLog("✔ TikTok đã được xóa")
            return true
        else
            nLog("Uninstall trả về: " .. tostring(msg))

            -- 🔥 QUAN TRỌNG: app không tồn tại
            if string.find(tostring(msg), "111") then
                nLog("✔ TikTok không tồn tại → OK")
                return true
            end
        end

        sys.sleep(5)
    end

    nLog("❌ Không thể đảm bảo TikTok đã xóa")
    return false
end

-- chạy check
ensureTikTokDeleted()


    

nLog("Open appstore...")
sys.sleep(2)
app.run("com.apple.AppStore")
sys.sleep(8)



local x, y
while x == nil do
    nLog("Find “profile” button…")
    sys.sleep(8)
    -- Generated code
    x, y = screen.find_color({
	{1128,253,0x007aff},
	{1127,218,0x007aff},
	{1129,283,0x007aff},
	{1089,284,0x007aff},
	{1167,285,0x007aff},
},95,1060,190,1172,324)
end

nLog("Tap “profile”…")
sys.sleep(2)
touch.tap(x, y)
sys.sleep(5)


local function tapWord(word)
    local txts, details = screen.ocr_text {}
    
    for i, v in ipairs(txts) do
        -- so sánh mềm (an toàn hơn)
        if string.find(string.lower(v), string.lower(word), 1, true) then
            touch.tap(details[i].center[1], details[i].center[2])
            return true
        end
    end

    return false
end

nLog("Tap 'Purchased'...")

while not tapWord("Purchased") do
    sys.msleep(300)
end

-- bấm lite
local function tapWord(word)
    local txts, details = screen.ocr_text {}
    
    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            touch.tap(details[i].center[1], details[i].center[2])
            return true
        end
    end

    return false
end

nLog("Tap 'Video'...")


local timeout = 300 -- số giây bạn muốn chờ
local start = os.time()

while (os.time() - start) < timeout do
    if tapWord("Video") then
        nLog("Đã tìm thấy và tap Video")
        break
    end

    sys.msleep(3000)
end

-- nếu hết thời gian mà chưa thấy
if (os.time() - start) >= timeout then
    nLog("Timeout: không tìm thấy Video")
end

sys.sleep(5)


local x, y
while x == nil do
    nLog("Find “tải về” button…")
    sys.sleep(5)
    -- Generated code
    x, y = screen.find_color({
	{504,1084,0x007aff},
	{505,1118,0x007aff},
	{529,1071,0x007aff},
	{476,1075,0x007aff},
	{505,1056,0x007aff},
},95,442,1032,578,1148)
end

nLog("Tap “tải về”…")
sys.sleep(2)
touch.tap(x, y)
sys.sleep(300)
app.close("com.apple.AppStore")
sys.sleep(2)
-- bấm open
local function hasWord(word)
    local txts, details = screen.ocr_text {}

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return true
        end
    end

    return false
end

nLog("Đợi thấy 'Tiktok'...")

local timeout = 900
local start = os.time()

while (os.time() - start) < timeout do
    if hasWord("tiktok") then
        nLog("Đã thấy Tiktok → mở app")
        sys.sleep(20)
        app.run("com.ss.iphone.ugc.Ame")
        break
    end

    sys.msleep(3000)
end

if (os.time() - start) >= timeout then
    nLog("Timeout: không thấy Tiktok")
end
sys.sleep(50)


-- bấm don't allow
local function tapDontAllow(timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        nLog("Đang tìm 'Don't Allow'...")

        local txts, details = screen.ocr_text {}

        for i, v in ipairs(txts) do
            local text = string.lower(v)

            if string.find(text, "don't allow") or string.find(text, "dont allow") then
                local x = details[i].center[1]
                local y = details[i].center[2]

                nLog("Thấy → tap")
                touch.tap(x, y)
                sys.sleep(1)

                -- 🔁 check lại 1 lần sau khi tap
                local txts2, details2 = screen.ocr_text {}
                for j, v2 in ipairs(txts2) do
                    local text2 = string.lower(v2)

                    if string.find(text2, "don't allow") or string.find(text2, "dont allow") then
                        local x2 = details2[j].center[1]
                        local y2 = details2[j].center[2]

                        nLog("Vẫn còn → tap lần 2")
                        touch.tap(x2, y2)
                        sys.sleep(1)
                        break
                    end
                end

                return true
            end
        end

        sys.msleep(1500) -- delay giữa mỗi lần check
    end

    nLog("Hết thời gian → không thấy")
    return false
end

-- ===== RUN =====
tapDontAllow(30) -- chờ tối đa 20s


sys.sleep(15)



-- tap nhiều ngẫu nhiên
math.randomseed(os.time())

local function tapMultiRandom(words, minTap, maxTap)
    local txts, details = screen.ocr_text {}
    local candidates = {}

    -- lấy danh sách match
    for i, v in ipairs(txts) do
        local text = string.lower(v)

        for _, w in ipairs(words) do
            if string.find(text, string.lower(w), 1, true) then
                table.insert(candidates, {
                    x = details[i].center[1],
                    y = details[i].center[2],
                    text = v
                })
                break
            end
        end
    end

    if #candidates == 0 then
        return false
    end

    -- shuffle danh sách
    for i = #candidates, 2, -1 do
        local j = math.random(i)
        candidates[i], candidates[j] = candidates[j], candidates[i]
    end

    -- random số lượng tap
    local count = math.random(minTap, maxTap)
    count = math.min(count, #candidates) -- tránh vượt quá

    nLog("Số lần tap: " .. count)

    -- tap
    for i = 1, count do
        local item = candidates[i]
        touch.tap(item.x, item.y)
        nLog("Tap: " .. item.text)
        sys.msleep(1000)
    end

    return true
end


local list = {"comedy", "daily", "dance"}

tapMultiRandom(list, 1, 3)

sys.sleep(5)


-- bấm next
local function tapWord(word)
    local txts, details = screen.ocr_text {}
    
    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            touch.tap(details[i].center[1], details[i].center[2])
            return true
        end
    end

    return false
end

nLog("Tap 'Next'...")

local timeout = 20 -- số giây bạn muốn chờ
local start = os.time()

while (os.time() - start) < timeout do
    if tapWord("Next") then
        nLog("Đã tìm thấy và tap Next")
        break
    end

    sys.msleep(3000)
end

-- nếu hết thời gian mà chưa thấy
if (os.time() - start) >= timeout then
    nLog("Timeout: không tìm thấy Next")
end

sys.sleep(10)

-- ================= SWIPE BLOCK =================

-- swipe chắc tay hơn
local function swipeUp()
    local w, h = screen.size()

    local x = w * (0.45 + math.random()*0.1)

    touch.on(x, h*0.85)          -- bắt đầu thấp hơn
        :move(x, h*0.65)
        :move(x, h*0.45)
        :move(x, h*0.20)         -- kết thúc cao hơn
        :step_delay(10 + math.random(5))
        :step_len(12 + math.random(4)) -- tăng lực
        :off()
end

-- OCR mềm hơn (tránh miss chữ Swipe)
local function hasWordSwipe()
    local txts, _ = screen.ocr_text {}

    for i, v in ipairs(txts) do
        local text = string.lower(v)

        if string.find(text, "swipe") 
        or string.find(text, "swlpe") 
        or string.find(text, "5wipe") then
            return true
        end
    end

    return false
end

nLog("Find Swipe...")

local timeout = 300
local start = os.time()
local found = false

-- tìm chữ Swipe
while (os.time() - start) < timeout do
    if hasWordSwipe() then
        found = true
        break
    end

    swipeUp()
    sys.msleep(5000)
end

-- ================= FLOW =================
if found then
    nLog("Đã thấy Swipe → vuốt")

    sys.msleep(1500)

    local count = math.random(1, 2)
    for i = 1, count do
        swipeUp()
        sys.msleep(2000)
    end

    nLog("Chờ 20s để Ask xuất hiện...")
    sys.msleep(15000)

else
    nLog("Không thấy Swipe → vuốt fallback")

    for i = 1, 2 do
        swipeUp()
        sys.msleep(2000)
    end
end
sys.sleep(10)

-- ================= END =================
    -- ================= TÌM & TAP ASK =================
local function tapAskNotTrack(timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        nLog("Đang tìm 'Ask App Not to Track'...")

        local txts, details = screen.ocr_text {}

        for i, v in ipairs(txts) do
            local text = string.lower(v)

            if string.find(text, "ask") 
            and string.find(text, "not") 
            and string.find(text, "track") then

                local x = details[i].center[1]
                local y = details[i].center[2]

                nLog("Thấy → tap lần 1")
                touch.tap(x, y)
                nLog("đã tap")
                sys.sleep(1.5)

                -- 🔁 CHECK LẠI 1 LẦN
                local txts2, details2 = screen.ocr_text {}

                for j, v2 in ipairs(txts2) do
                    local text2 = string.lower(v2)

                    if string.find(text2, "ask") 
                    and string.find(text2, "not") 
                    and string.find(text2, "track") then

                        local x2 = details2[j].center[1]
                        local y2 = details2[j].center[2]

                        nLog("Vẫn còn → tap lần 2")
                        touch.tap(x2, y2)
                        sys.sleep(1)
                        break
                    end
                end

                return true
            end
        end

        sys.msleep(1500)
    end

    nLog("Hết thời gian → không thấy")
    return false
end

-- ===== RUN =====
tapAskNotTrack(30)
sys.sleep(8)
    -- ================= SWIPE RANDOM SAU ĐÓ =================
    local count = math.random(2, 3)
    nLog("Swipe tiếp: " .. count .. " lần")

    for i = 1, count do
        swipeUp()

        local delay = math.random(8000, 15000)
        nLog("Chờ: " .. delay .. " ms")
        sys.msleep(delay)
    end
sys.sleep(8)

app.close("com.ss.iphone.ugc.Ame")

sys.sleep(5)

app.run("com.tigisoftware.ADManager")
            nLog("mở manager")
sys.sleep(3)
local function tapAskNotTrack(timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        nLog("Đang tìm 'Ask App Not to Track'...")

        local txts, details = screen.ocr_text {}

        for i, v in ipairs(txts) do
            local text = string.lower(v)

            if string.find(text, "ask") 
            and string.find(text, "not") 
            and string.find(text, "track") then

                local x = details[i].center[1]
                local y = details[i].center[2]

                nLog("Thấy → tap lần 1")
                touch.tap(x, y)
                nLog("đã tap")
                sys.sleep(1.5)

                -- 🔁 CHECK LẠI 1 LẦN
                local txts2, details2 = screen.ocr_text {}

                for j, v2 in ipairs(txts2) do
                    local text2 = string.lower(v2)

                    if string.find(text2, "ask") 
                    and string.find(text2, "not") 
                    and string.find(text2, "track") then

                        local x2 = details2[j].center[1]
                        local y2 = details2[j].center[2]

                        nLog("Vẫn còn → tap lần 2")
                        touch.tap(x2, y2)
                        sys.sleep(1)
                        break
                    end
                end

                return true
            end
        end

        sys.msleep(1500)
    end

    nLog("Hết thời gian → không thấy")
    return false
end

-- ===== RUN =====
tapAskNotTrack(5)            
sys.sleep(3)

-- ================= CONFIG =================
-- chỉnh vùng scan cho phù hợp máy bạn
local SCAN_REGION = {
    x = 30,
    y = 488,      -- bỏ header phía trên
    width = 547,
    height = 1054
}

-- ================= FUNCTION =================
-- tìm text trong vùng
local function findTextInRegion(word)
    local txts, details = screen.ocr_text {
        region = SCAN_REGION
    }

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return details[i].center[1], details[i].center[2], v
        end
    end

    return nil, nil, nil
end

-- tap text trong vùng + timeout
local function tapTextInRegion(word, timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        local x, y, text = findTextInRegion(word)

        if x ~= nil then
            nLog("Tap: " .. text .. " tại (" .. x .. "," .. y .. ")")
            touch.tap(x, y)
            return true
        end

        sys.msleep(300)
    end

    nLog("Timeout: không tìm thấy " .. word)
    return false
end

-- ================= USE =================
nLog("Tap 'TikTok' trong manager...")

if tapTextInRegion("TikTok", 20) then
    sys.sleep(2) -- chờ chuyển màn
else
    nLog("Không tìm thấy TikTok")
end



-- chỉnh vùng scan cho phù hợp máy bạn
local SCAN_REGION = {
    x = 1,
    y = 1543,      -- bỏ header phía trên
    width = 381,
    height = 1681
}

-- ================= FUNCTION =================
-- tìm text trong vùng
local function findTextInRegion(word)
    local txts, details = screen.ocr_text {
        region = SCAN_REGION
    }

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return details[i].center[1], details[i].center[2], v
        end
    end

    return nil, nil, nil
end

-- tap text trong vùng + timeout
local function tapTextInRegion(word, timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        local x, y, text = findTextInRegion(word)

        if x ~= nil then
            nLog("Tap: " .. text .. " tại (" .. x .. "," .. y .. ")")
            touch.tap(x, y)
            return true
        end

        sys.msleep(300)
    end

    nLog("Timeout: không tìm thấy " .. word)
    return false
end

-- ================= USE =================
nLog("Tap 'Backup' trong vùng list...")

if tapTextInRegion("Backup", 20) then
    sys.sleep(2) -- chờ chuyển màn
else
    nLog("Không tìm thấy Backup")
end
sys.sleep(5)

local x, y
while x == nil do
    nLog("Find “Backup” button…")
    sys.sleep(5)
    -- Generated code
	x, y = screen.find_color({
	{372,1901,0x007aff},
	{869,1910,0x007aff},
	{619,1884,0x007aff},
	{485,1898,0x007aff},
	{642,1900,0x238bfd},
	{731,1904,0x007aff},
},95,288,1819,955,1987)
end

nLog("Tap “Backup”…")
sys.sleep(2)
touch.tap(x, y)
sys.sleep(5)


local x, y
while x == nil do
    nLog("Find “Backing...” button…")
    sys.sleep(20)
    -- Generated code
	x, y = screen.find_color({
	{471,1008,0xffffff},
	{580,1008,0xffffff},
	{516,1059,0x007aff},
	{654,1057,0x007aff},
	{581,1089,0x007aff},
},95,0,0,0,0)
end
sys.sleep(5)
            
            
local SCAN_REGION = {
    x = 3,
    y = 1925,      -- bỏ header phía trên
    width = 348,
    height = 2055
}

-- ================= FUNCTION =================
-- tìm text trong vùng
local function findTextInRegion(word)
    local txts, details = screen.ocr_text {
        region = SCAN_REGION
    }

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return details[i].center[1], details[i].center[2], v
        end
    end

    return nil, nil, nil
end

-- tap text trong vùng + timeout
local function tapTextInRegion(word, timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        local x, y, text = findTextInRegion(word)

        if x ~= nil then
            nLog("Tap: " .. text .. " tại (" .. x .. "," .. y .. ")")
            touch.tap(x, y)
            return true
        end

        sys.msleep(1000)
    end

    nLog("Timeout: không tìm thấy " .. word)
    return false
end

-- ================= USE =================
nLog("Tap 'wipe' trong vùng list...")

if tapTextInRegion("Wipe", 20) then
    sys.sleep(2) -- chờ chuyển màn
else
    nLog("Không tìm thấy Wipe")
end
sys.sleep(5)
local x, y
while x == nil do
    nLog("Find “wipe” button…")
    sys.sleep(5)
    -- Generated code
	x, y = screen.find_color({
	{401,1889,0xff3b30},
	{458,1886,0xff3b30},
	{588,1884,0xff3b30},
	{693,1885,0xfc5a51},
	{807,1896,0xff3b30},
},95,345,1822,936,1985)
end

sys.sleep(2)
touch.tap(x, y)
sys.toast("đã bấm wipe", 0)
nLog("đã bấm wipe")
sys.sleep(10)

app.quit("*")

sys.sleep(5)

local function hasWord(word)
    local txts, details = screen.ocr_text {}

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return true
        end
    end

    return false
end

nLog("Đợi thấy 'Tiktok'...")

local timeout = 10
local start = os.time()

while (os.time() - start) < timeout do
    if hasWord("tiktok") then
        nLog("Đã thấy Tiktok → xóa app")
        app.uninstall("com.ss.iphone.ugc.Ame")
        break
    end

    sys.msleep(3000)
end

if (os.time() - start) >= timeout then
    nLog("Timeout: không thấy Tiktok")
end            
sys.sleep(5)

-- 🔥 QUIT ALL APP SAU KHI CLEAN
nLog("Quit all app...")
app.quit("*")

sys.sleep(5)

nLog("Kết thúc")


sys.sleep(5)
            -- ================= FINAL CLEAN UP (SAU KHI CHẠY XONG 1 VÒNG) =================
-- ================= FINAL CLEAN UP (SAU KHI CHẠY XONG 1 VÒNG) =================
nLog("===== FINAL CLEAN UP =====")

local bundle = "com.ss.iphone.ugc.Ame"

-- 🔥 CHECK TRỰC TIẾP BUNDLE (KHÔNG DÙNG OCR)
nLog("🔍 Check TikTokLite còn hay không...")

local maxTry = 3
local count = 0

while count < maxTry do
    if not app.installed(bundle) then
        nLog("✔ Không còn TikTokLite → thoát clean")
        break
    end

    nLog("⚠ TikTokLite vẫn còn → uninstall lần " .. (count + 1))

    local ok, msg = app.uninstall(bundle)

    if ok then
        nLog("✔ Đã gọi uninstall")
    else
        nLog("❌ Lỗi uninstall: " .. tostring(msg))
    end

    sys.sleep(3) -- đợi hệ thống xóa thật
    count = count + 1
end

if count == maxTry then
    nLog("❌ Vẫn còn TikTokLite sau " .. maxTry .. " lần thử")
end

sys.sleep(3)

-- 🔥 QUIT ALL APP SAU KHI CLEAN
nLog("🚀 Quit all app...")
app.quit("*")

sys.sleep(5)

nLog("===== END CLEAN CYCLE =====")


    end)

    if not ok then
        nLog("❌ Lỗi vòng " .. cycle .. ": " .. tostring(err))
    else
        nLog("✅ Hoàn thành vòng " .. cycle)
    end

    -- nghỉ giữa các vòng (rất quan trọng để tránh dính trạng thái hệ thống)
    if cycle < 3 then
        nLog("⏳ Nghỉ trước vòng tiếp...")
        sys.sleep(10) -- có thể tăng 20-30s nếu máy yếu
    end
end

nLog("🎉 DONE 3 CYCLES")