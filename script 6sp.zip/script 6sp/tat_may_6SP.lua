local x, y
while x == nil do
    nLog("Find “<” button…")
    sys.sleep(2)
    -- Generated code
    x, y = screen.find_color({
	{77,104,0x000000},
	{57,125,0x000000},
	{75,145,0x000000},
	{66,112,0x000000},
	{66,137,0x000000},
},95,21,72,139,177)
end

nLog("Tap “<”…")
sys.sleep(2)
touch.tap(x, y)
sys.sleep(2)


function resetWifiIfOn()
    if device.is_wifi_on() then
        nLog("📶 WiFi đang ON → tiến hành reset")

        device.turn_off_wifi()
        nLog("🔌 Đã tắt WiFi")

        sys.sleep(5)

        device.turn_on_wifi()
        nLog("📡 Đã bật lại WiFi")

        -- chờ ổn định mạng
        sys.sleep(3)

        return true
    else
        nLog("⚠️ WiFi đang OFF → không cần reset")
        return false
    end
end

resetWifiIfOn()
sys.sleep(2)
key.press("LOCK")
nLog("Locked")