local x, y
while x == nil do
    nLog("Find “<” button…")
    sys.sleep(2)
    -- Generated code
    x, y = screen.find_color({
	{48,72,0x000000},
	{37,84,0x000000},
	{50,97,0x000000},
	{41,89,0x000000},
	{44,75,0x000000},
},95,22,52,77,118)
end

nLog("Tap “<”…")
sys.sleep(2)
touch.tap(x, y)
sys.sleep(2)


function resetWifiIfOn()
    if device.is_wifi_on() then
        nLog("📶 WiFi đang ON → tiến hành reset")

        device.turn_off_wifi()
        nLog("🔌 Đã tắt WiFi")

        sys.sleep(5)

        device.turn_on_wifi()
        nLog("📡 Đã bật lại WiFi")

        -- chờ ổn định mạng
        sys.sleep(3)

        return true
    else
        nLog("⚠️ WiFi đang OFF → không cần reset")
        return false
    end
end

resetWifiIfOn()
sys.sleep(2)
key.press("LOCK")
nLog("Locked")