sys.toast("BẮT ĐẦU LÀM PHÔI",0)
for cycle = 1, 3 do
    nLog("===== START CYCLE: " .. cycle .. " =====")

    local ok, err = pcall(function()

         nLog("===== START NEW CYCLE =====")
    -- ================= CHECK & FORCE DELETE TIKTOK =================
nLog("🔍 Check TikTok trước khi chạy...")

local function ensureTikTokDeleted()
    local retry = 0
    local MAX_RETRY = 5

    while retry < MAX_RETRY do
        retry = retry + 1
        nLog("Check uninstall lần: " .. retry)

        local ok, msg = app.uninstall("com.ss.iphone.ugc.Ame")
        sys.sleep(5)
		app.quit("*")
        sys.sleep(2)
        if ok then
            nLog("✔ TikTok đã được xóa")
            return true
        else
            nLog("Uninstall trả về: " .. tostring(msg))

            -- 🔥 QUAN TRỌNG: app không tồn tại
            if string.find(tostring(msg), "111") then
                nLog("✔ TikTok không tồn tại → OK")
                return true
            end
        end

        sys.sleep(5)
    end

    nLog("❌ Không thể đảm bảo TikTok đã xóa")
    return false
end

-- chạy check
ensureTikTokDeleted()


    

nLog("Open appstore...")
sys.sleep(2)
app.run("com.apple.AppStore")
sys.sleep(8)



local x, y
while x == nil do
    nLog("Find “profile” button…")
    sys.sleep(8)
    -- Generated code
    x, y = screen.find_color({
	{674,170,0x007aff},
	{649,163,0x007aff},
	{704,175,0x007aff},
	{673,197,0x007aff},
},95,0,0,0,0)
end

nLog("Tap “profile”…")
sys.sleep(2)
touch.tap(x, y)
sys.sleep(5)


local function tapWord(word)
    local txts, details = screen.ocr_text {}
    
    for i, v in ipairs(txts) do
        -- so sánh mềm (an toàn hơn)
        if string.find(string.lower(v), string.lower(word), 1, true) then
            touch.tap(details[i].center[1], details[i].center[2])
            return true
        end
    end

    return false
end

nLog("Tap 'Purchased'...")

while not tapWord("Purchased") do
    sys.msleep(300)
end

-- bấm lite
local function tapWord(word)
    local txts, details = screen.ocr_text {}
    
    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            touch.tap(details[i].center[1], details[i].center[2])
            return true
        end
    end

    return false
end

nLog("Tap 'Video'...")


local timeout = 300 -- số giây bạn muốn chờ
local start = os.time()

while (os.time() - start) < timeout do
    if tapWord("Video") then
        nLog("Đã tìm thấy và tap Lite")
        break
    end

    sys.msleep(3000)
end

-- nếu hết thời gian mà chưa thấy
if (os.time() - start) >= timeout then
    nLog("Timeout: không tìm thấy Video")
end

sys.sleep(5)


local x, y
while x == nil do
    nLog("Find “tải về” button…")
    sys.sleep(5)
    -- Generated code
    x, y = screen.find_color({
	{336,415,0x007aff},
	{314,402,0x007aff},
	{337,377,0x007aff},
	{360,397,0x007aff},
	{336,402,0x007aff},
},95,0,0,0,0)
end

nLog("Tap “tải về”…")
sys.sleep(2)
touch.tap(x, y)
sys.sleep(300)
app.close("com.apple.AppStore")
sys.sleep(2)
-- bấm open
local function hasWord(word)
    local txts, details = screen.ocr_text {}

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return true
        end
    end

    return false
end

nLog("Đợi thấy 'Tiktok'...")

local timeout = 900
local start = os.time()

while (os.time() - start) < timeout do
    if hasWord("tiktok") then
        nLog("Đã thấy Tiktok → mở app")
        sys.sleep(20)
        app.run("com.ss.iphone.ugc.Ame")
        break
    end

    sys.msleep(3000)
end

if (os.time() - start) >= timeout then
    nLog("Timeout: không thấy Tiktok")
end
sys.sleep(50)


-- bấm don't allow
local function tapDontAllow(timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        nLog("Đang tìm 'Don't Allow'...")

        local txts, details = screen.ocr_text {}

        for i, v in ipairs(txts) do
            local text = string.lower(v)

            if string.find(text, "don't allow") or string.find(text, "dont allow") then
                local x = details[i].center[1]
                local y = details[i].center[2]

                nLog("Thấy → tap")
                touch.tap(x, y)
                sys.sleep(1)

                -- 🔁 check lại 1 lần sau khi tap
                local txts2, details2 = screen.ocr_text {}
                for j, v2 in ipairs(txts2) do
                    local text2 = string.lower(v2)

                    if string.find(text2, "don't allow") or string.find(text2, "dont allow") then
                        local x2 = details2[j].center[1]
                        local y2 = details2[j].center[2]

                        nLog("Vẫn còn → tap lần 2")
                        touch.tap(x2, y2)
                        sys.sleep(1)
                        break
                    end
                end

                return true
            end
        end

        sys.msleep(1500) -- delay giữa mỗi lần check
    end

    nLog("Hết thời gian → không thấy")
    return false
end

-- ===== RUN =====
tapDontAllow(30) -- chờ tối đa 20s


sys.sleep(15)



-- tap nhiều ngẫu nhiên
math.randomseed(os.time())

local function tapMultiRandom(words, minTap, maxTap)
    local txts, details = screen.ocr_text {}
    local candidates = {}

    -- lấy danh sách match
    for i, v in ipairs(txts) do
        local text = string.lower(v)

        for _, w in ipairs(words) do
            if string.find(text, string.lower(w), 1, true) then
                table.insert(candidates, {
                    x = details[i].center[1],
                    y = details[i].center[2],
                    text = v
                })
                break
            end
        end
    end

    if #candidates == 0 then
        return false
    end

    -- shuffle danh sách
    for i = #candidates, 2, -1 do
        local j = math.random(i)
        candidates[i], candidates[j] = candidates[j], candidates[i]
    end

    -- random số lượng tap
    local count = math.random(minTap, maxTap)
    count = math.min(count, #candidates) -- tránh vượt quá

    nLog("Số lần tap: " .. count)

    -- tap
    for i = 1, count do
        local item = candidates[i]
        touch.tap(item.x, item.y)
        nLog("Tap: " .. item.text)
        sys.msleep(1000)
    end

    return true
end


local list = {"comedy", "daily", "dance"}

tapMultiRandom(list, 1, 3)

sys.sleep(5)


-- bấm next
local function tapWord(word)
    local txts, details = screen.ocr_text {}
    
    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            touch.tap(details[i].center[1], details[i].center[2])
            return true
        end
    end

    return false
end

nLog("Tap 'Next'...")

local timeout = 20 -- số giây bạn muốn chờ
local start = os.time()

while (os.time() - start) < timeout do
    if tapWord("Next") then
        nLog("Đã tìm thấy và tap Next")
        break
    end

    sys.msleep(3000)
end

-- nếu hết thời gian mà chưa thấy
if (os.time() - start) >= timeout then
    nLog("Timeout: không tìm thấy Next")
end

sys.sleep(10)

-- ================= SWIPE BLOCK =================

-- swipe chắc tay hơn
local function swipeUp()
    touch.on(375, 1100)
        :move(375, 900)
        :move(375, 700)
        :move(375, 500)
        :move(375, 300)
        :step_delay(15)
        :step_len(5)
        :off()
end

-- OCR mềm hơn (tránh miss chữ Swipe)
local function hasWordSwipe()
    local txts, _ = screen.ocr_text {}

    for i, v in ipairs(txts) do
        local text = string.lower(v)

        if string.find(text, "swipe") 
        or string.find(text, "swlpe") 
        or string.find(text, "5wipe") then
            return true
        end
    end

    return false
end

nLog("Find Swipe...")

local timeout = 300
local start = os.time()
local found = false

-- tìm chữ Swipe
while (os.time() - start) < timeout do
    if hasWordSwipe() then
        found = true
        break
    end

    swipeUp()
    sys.msleep(5000)
end

-- ================= FLOW =================
if found then
    nLog("Đã thấy Swipe → vuốt")

    sys.msleep(1500)

    local count = math.random(1, 2)
    for i = 1, count do
        swipeUp()
        sys.msleep(2000)
    end

    nLog("Chờ 20s để Ask xuất hiện...")
    sys.msleep(15000)

else
    nLog("Không thấy Swipe → vuốt fallback")

    for i = 1, 2 do
        swipeUp()
        sys.msleep(2000)
    end
end
sys.sleep(10)

-- ================= END =================
    -- ================= TÌM & TAP ASK =================
local function tapAskNotTrack(timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        nLog("Đang tìm 'Ask App Not to Track'...")

        local txts, details = screen.ocr_text {}

        for i, v in ipairs(txts) do
            local text = string.lower(v)

            if string.find(text, "ask") 
            and string.find(text, "not") 
            and string.find(text, "track") then

                local x = details[i].center[1]
                local y = details[i].center[2]

                nLog("Thấy → tap lần 1")
                touch.tap(x, y)
                nLog("đã tap")
                sys.sleep(1.5)

                -- 🔁 CHECK LẠI 1 LẦN
                local txts2, details2 = screen.ocr_text {}

                for j, v2 in ipairs(txts2) do
                    local text2 = string.lower(v2)

                    if string.find(text2, "ask") 
                    and string.find(text2, "not") 
                    and string.find(text2, "track") then

                        local x2 = details2[j].center[1]
                        local y2 = details2[j].center[2]

                        nLog("Vẫn còn → tap lần 2")
                        touch.tap(x2, y2)
                        sys.sleep(1)
                        break
                    end
                end

                return true
            end
        end

        sys.msleep(1500)
    end

    nLog("Hết thời gian → không thấy")
    return false
end

-- ===== RUN =====
tapAskNotTrack(30)
sys.sleep(8)

    -- ================= SWIPE RANDOM SAU ĐÓ =================
    local count = math.random(2, 3)
    nLog("Swipe tiếp: " .. count .. " lần")

    for i = 1, count do
        swipeUp()

        local delay = math.random(8000, 15000)
        nLog("Chờ: " .. delay .. " ms")
        sys.msleep(delay)
    end
sys.sleep(8)

        
app.close("com.ss.iphone.ugc.Ame")

sys.sleep(5)

app.run("com.tigisoftware.ADManager")
            nLog("mở manager")
sys.sleep(3)
local function tapAskNotTrack(timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        nLog("Đang tìm 'Ask App Not to Track'...")

        local txts, details = screen.ocr_text {}

        for i, v in ipairs(txts) do
            local text = string.lower(v)

            if string.find(text, "ask") 
            and string.find(text, "not") 
            and string.find(text, "track") then

                local x = details[i].center[1]
                local y = details[i].center[2]

                nLog("Thấy → tap lần 1")
                touch.tap(x, y)
                nLog("đã tap")
                sys.sleep(1.5)

                -- 🔁 CHECK LẠI 1 LẦN
                local txts2, details2 = screen.ocr_text {}

                for j, v2 in ipairs(txts2) do
                    local text2 = string.lower(v2)

                    if string.find(text2, "ask") 
                    and string.find(text2, "not") 
                    and string.find(text2, "track") then

                        local x2 = details2[j].center[1]
                        local y2 = details2[j].center[2]

                        nLog("Vẫn còn → tap lần 2")
                        touch.tap(x2, y2)
                        sys.sleep(1)
                        break
                    end
                end

                return true
            end
        end

        sys.msleep(1500)
    end

    nLog("Hết thời gian → không thấy")
    return false
end
tapAskNotTrack(5)
sys.sleep(3)

-- ================= CONFIG =================
-- chỉnh vùng scan cho phù hợp máy bạn
local SCAN_REGION = {
    x = 90,
    y = 512,      -- bỏ header phía trên
    width = 300,
    height = 600
}

-- ================= FUNCTION =================
-- tìm text trong vùng
local function findTextInRegion(word)
    local txts, details = screen.ocr_text {
        region = SCAN_REGION
    }

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return details[i].center[1], details[i].center[2], v
        end
    end

    return nil, nil, nil
end

-- tap text trong vùng + timeout
local function tapTextInRegion(word, timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        local x, y, text = findTextInRegion(word)

        if x ~= nil then
            nLog("Tap: " .. text .. " tại (" .. x .. "," .. y .. ")")
            touch.tap(x, y)
            return true
        end

        sys.msleep(300)
    end

    nLog("Timeout: không tìm thấy " .. word)
    return false
end

-- ================= USE =================
nLog("Tap 'TikTok' trong manager...")

if tapTextInRegion("TikTok", 20) then
    sys.sleep(2) -- chờ chuyển màn
else
    nLog("Không tìm thấy TikTok")
end



-- chỉnh vùng scan cho phù hợp máy bạn
local SCAN_REGION = {
    x = 4,
    y = 1034,      -- bỏ header phía trên
    width = 742,
    height = 1203
}

-- ================= FUNCTION =================
-- tìm text trong vùng
local function findTextInRegion(word)
    local txts, details = screen.ocr_text {
        region = SCAN_REGION
    }

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return details[i].center[1], details[i].center[2], v
        end
    end

    return nil, nil, nil
end

-- tap text trong vùng + timeout
local function tapTextInRegion(word, timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        local x, y, text = findTextInRegion(word)

        if x ~= nil then
            nLog("Tap: " .. text .. " tại (" .. x .. "," .. y .. ")")
            touch.tap(x, y)
            return true
        end

        sys.msleep(300)
    end

    nLog("Timeout: không tìm thấy " .. word)
    return false
end

-- ================= USE =================
nLog("Tap 'Backup' trong vùng list...")

if tapTextInRegion("Backup", 20) then
    sys.sleep(2) -- chờ chuyển màn
else
    nLog("Không tìm thấy Backup")
end
sys.sleep(5)

local x, y
while x == nil do
    nLog("Find “Backup” button…")
    sys.sleep(5)
    -- Generated code
	x, y = screen.find_color({
	{211,1131,0x007aff},
	{311,1143,0xf2f1f0},
	{309,1139,0x007aff},
	{357,1119,0x007aff},
	{374,1118,0x007aff},
	{454,1141,0x007aff},
	{488,1119,0x1f89fd},
	{507,1135,0x007aff},
	{543,1141,0x3695fc},
},95,0,0,0,0)
end

nLog("Tap “Backup”…")
sys.sleep(2)
touch.tap(x, y)
sys.sleep(5)


local x, y
while x == nil do
    nLog("Find “Backing...” button…")
    sys.sleep(15)
    -- Generated code
	x, y = screen.find_color({
        {252,637,0x000000},
        {294,636,0x000000},
        {326,671,0xc6c6c8},
        {377,712,0x75b7ff},
        {328,703,0x007aff},
        {419,704,0x007aff},
    },95,0,0,0,0)
end
sys.sleep(2)
local function tapWord(word)
  local txts, details = screen.ocr_text {}
  local tapped = false
  for i, v in ipairs(txts) do
    if v == word then
      touch.tap(details[i].center[1], details[i].center[2])
      tapped = true
    end
  end
  return tapped
end


--app.run("com.apple.Preferences")
sys.sleep(5)

nLog("Test gestures…")
while not tapWord("Wipe") do
  touch.on(375, 1100)
    :move(375, 275)
    :step_delay(20)
    :step_len(1)
    :move(375, 255)
    :off()
  sys.sleep(1)
end
sys.sleep(5)


local x, y
while x == nil do
    nLog("Find “wipe” button…")
    sys.sleep(5)
    -- Generated code
	x, y = screen.find_color({
	{229,1121,0xff3b30},
	{244,1120,0xff3b30},
	{413,1135,0xff3b30},
	{480,1134,0xff3b30},
	{513,1134,0xff3b30},
	{353,1118,0xff3b30},
	{266,1118,0xff3b30},
},95,0,0,0,0)
end

sys.sleep(2)
touch.tap(x, y)
sys.toast("đã bấm wipe", 0)
nLog("đã bấm wipe")
sys.sleep(10)

app.quit("*")

sys.sleep(5)

local function hasWord(word)
    local txts, details = screen.ocr_text {}

    for i, v in ipairs(txts) do
        if string.find(string.lower(v), string.lower(word), 1, true) then
            return true
        end
    end

    return false
end

nLog("Đợi thấy 'Tiktok'...")

local timeout = 10
local start = os.time()

while (os.time() - start) < timeout do
    if hasWord("tiktok") then
        nLog("Đã thấy Tiktok → xóa app")
        app.uninstall("com.ss.iphone.ugc.Ame")
        break
    end

    sys.msleep(3000)
end

if (os.time() - start) >= timeout then
    nLog("Timeout: không thấy Tiktok")
end            
sys.sleep(5)

-- 🔥 QUIT ALL APP SAU KHI CLEAN
nLog("Quit all app...")
app.quit("*")

sys.sleep(5)

nLog("Kết thúc")


sys.sleep(5)
            -- ================= FINAL CLEAN UP (SAU KHI CHẠY XONG 1 VÒNG) =================
-- ================= FINAL CLEAN UP (SAU KHI CHẠY XONG 1 VÒNG) =================
nLog("===== FINAL CLEAN UP =====")

local bundle = "com.ss.iphone.ugc.Ame"

-- 🔥 CHECK TRỰC TIẾP BUNDLE (KHÔNG DÙNG OCR)
nLog("🔍 Check TikTokLite còn hay không...")

local maxTry = 3
local count = 0

while count < maxTry do
    if not app.installed(bundle) then
        nLog("✔ Không còn TikTokLite → thoát clean")
        break
    end

    nLog("⚠ TikTokLite vẫn còn → uninstall lần " .. (count + 1))

    local ok, msg = app.uninstall(bundle)

    if ok then
        nLog("✔ Đã gọi uninstall")
    else
        nLog("❌ Lỗi uninstall: " .. tostring(msg))
    end

    sys.sleep(3) -- đợi hệ thống xóa thật
    count = count + 1
end

if count == maxTry then
    nLog("❌ Vẫn còn TikTokLite sau " .. maxTry .. " lần thử")
end

sys.sleep(3)

-- 🔥 QUIT ALL APP SAU KHI CLEAN
nLog("🚀 Quit all app...")
app.quit("*")

sys.sleep(5)

nLog("===== END CLEAN CYCLE =====")


    end)

    if not ok then
        nLog("❌ Lỗi vòng " .. cycle .. ": " .. tostring(err))
    else
        nLog("✅ Hoàn thành vòng " .. cycle)
    end

    -- nghỉ giữa các vòng (rất quan trọng để tránh dính trạng thái hệ thống)
    if cycle < 3 then
        nLog("⏳ Nghỉ trước vòng tiếp...")
        sys.sleep(10) -- có thể tăng 20-30s nếu máy yếu
    end
end

nLog("🎉 DONE 3 CYCLES")