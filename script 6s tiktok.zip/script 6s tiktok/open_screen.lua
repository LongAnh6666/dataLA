function pressHomeLikeHuman()
    nLog("👆 Simulate HOME like human")

    -- lần 1
    key.down("HOMEBUTTON")
    sys.msleep(math.random(80, 180)) -- giữ ngẫu nhiên
    key.up("HOMEBUTTON")

    -- delay giữa 2 lần bấm (quan trọng)
    sys.msleep(math.random(400, 600))

    -- lần 2
    key.down("HOMEBUTTON")
    sys.msleep(math.random(80, 180))
    key.up("HOMEBUTTON")

    -- chờ hệ thống phản hồi
    sys.sleep(math.random(1, 2))

    nLog("✅ Done HOME press")
end

pressHomeLikeHuman()