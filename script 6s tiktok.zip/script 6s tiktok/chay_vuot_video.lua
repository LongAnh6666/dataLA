math.randomseed(os.time())

function swipeHuman(x1, y1, x2, y2)
    local finger = 1

    -- ===== random kiểu vuốt =====
    local mode = math.random(1, 3)

    local steps, minDelay, maxDelay

    if mode == 1 then
        -- 🐢 vuốt chậm
        steps = math.random(60, 90)
        minDelay = 10
        maxDelay = 18
        nLog("🐢 Swipe chậm")
    elseif mode == 2 then
        -- 🚶 vuốt bình thường
        steps = math.random(40, 70)
        minDelay = 6
        maxDelay = 12
        nLog("🚶 Swipe bình thường")
    else
        -- ⚡ vuốt nhanh (flick)
        steps = math.random(20, 35)
        minDelay = 2
        maxDelay = 6
        nLog("⚡ Swipe nhanh")
    end

    touch.on(finger, x1, y1)

    for i = 1, steps do
        local t = i / steps

        -- easing khác nhau theo mode
        local ease
        if mode == 3 then
            -- flick: nhanh đầu, chậm cuối
            ease = t * t
        else
            -- bình thường
            ease = t * t * (3 - 2 * t)
        end

        local nx = x1 + (x2 - x1) * ease
        local ny = y1 + (y2 - y1) * ease

        -- noise
        nx = nx + math.random(-2, 2)
        ny = ny + math.random(-1, 1)

        touch.move(finger, nx, ny)

        -- delay random theo mode
        sys.msleep(math.random(minDelay, maxDelay))
    end

    touch.off(finger)

    nLog("✅ Đã vuốt xong | mode=" .. mode .. " | steps=" .. steps)
end

local CHECK_REGION = {
    x = 244,
    y = 585,
    width = 362,   -- 118
    height = 687   -- 102
}

local function checkNumber02()
    local txts, details = screen.ocr_text {
        region = CHECK_REGION
    }

    for i, v in ipairs(txts) do
        local text = string.lower(v)

        -- log để debug
        nLog("OCR thấy: " .. text)

        -- ===== normalize =====
        text = string.gsub(text, "o", "0")
        text = string.gsub(text, "%s+", "")

        -- ===== check đúng logic =====
        -- chỉ cần bắt đầu bằng 02
        if string.sub(text, 1, 2) == "02" then
            nLog("🎯 FOUND 02 trong: " .. text)
            return true
        end
    end

    return false
end

local function checkAndSwipe02(timeout)
    local start = os.time()

    while (os.time() - start) < timeout do
        if checkNumber02() then
            nLog("🚀 Có '02' → SWIPE")

            swipeHuman(721, 1234, 28, 1234)
            return true
        end

        nLog("⏳ Chưa thấy 02...")
        sys.msleep(300)
    end

    nLog("❌ Timeout không thấy 02")
    return false
end

--checkAndSwipe02(30)

while true do
    local ok, err = pcall(function()

        nLog("===== LOOP START =====")

        if checkNumber02() then
            nLog("🚀 Có 02 → swipe")
            swipeHuman(721, 1234, 28, 1234)
        end

    end)

    if not ok then
        nLog("❌ Lỗi: " .. tostring(err))
    end

    sys.msleep(10000)
end